export default { name: "acme-archive", setup() {} };
